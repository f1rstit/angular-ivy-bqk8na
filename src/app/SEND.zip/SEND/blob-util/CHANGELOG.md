Changelog
====

## v2.0.0

- Removed built-in `Promise` polyfill
- Some APIs that returned `Promise`s now return bare values.
- Removed Bower support
- Added ES module support
- Added TypeScript support
- Added `arrayBufferToBinaryString()` and `binaryStringToArrayBuffer()`

## v1.0.0

- Initial release