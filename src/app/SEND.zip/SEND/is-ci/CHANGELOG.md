# Changelog

## v3.0.1

- remove `.github` folder from published files ([dd15229](https://github.com/watson/is-ci/commit/dd15229))

## v3.0.0

Breaking changes:

- update to `ci-info` v3. This drops support for EOL node versions 6, 13

## v2.0.0

Breaking changes:

- Drop support for Node.js end-of-life versions: 0.10, 0.12, 4, 5, 7,
  and 9

Other changes:

See [ci-info
changelog](https://github.com/watson/ci-info/blob/master/CHANGELOG.md#v200)
for a list of newly supported CI servers.
