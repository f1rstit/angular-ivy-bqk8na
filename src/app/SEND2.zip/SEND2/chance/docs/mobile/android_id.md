# android_id

```js
// usage
chance.android_id()
```

Return a random GCM registration ID.

```js
chance.android_id()
=> 'APA91HHQyPlWqV2Nu61LRs41eE4vrR4bHLKTs0-Dh5nDLopcWZotLw77NEoJyADNJiq6cwY0jMM02y8aacLs6fe2_ynweFjZJVVevKON-32826v-EFoayyThU3-42YEUY9pCScU_n73yRNSOlTk5W6iPtrDkQ3a6_BvOxRbSYi3E6QEY0ZuIQF0'
```
