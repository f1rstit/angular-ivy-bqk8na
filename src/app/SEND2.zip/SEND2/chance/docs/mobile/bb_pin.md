# bb_pin

```js
// usage
chance.bb_pin()
```

Return a random BlackBerry Device PIN

```js
chance.bb_pin()
=> '985de771'
```
