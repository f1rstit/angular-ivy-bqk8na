# wp7_anid

```js
// usage
chance.wp7_anid()
```

Return a random Windows Phone 7 ANID

```js
chance.wp7_anid()
=> 'A=3FC2491A0E0C5AB7824B2F60DCE4DB02&E=4e7&W=6'
```
