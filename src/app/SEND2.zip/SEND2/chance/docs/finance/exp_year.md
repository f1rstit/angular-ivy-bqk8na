# exp_year

```js
// usage
chance.exp_year()
```

Generate a random credit card expiration year.

```js
chance.exp_year();
=> '2018'
```

Returns a random year between today and 10 years in the future.
