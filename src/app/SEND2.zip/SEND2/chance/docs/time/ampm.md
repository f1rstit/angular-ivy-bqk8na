# ampm

```js
// usage
chance.ampm()
```

Return am or pm. Very simple.

```js
chance.ampm();
=> 'am'
```
