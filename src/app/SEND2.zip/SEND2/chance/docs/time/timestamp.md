# timestamp

```js
// usage
chance.timestamp()
```

Generate a random timestamp. This is a standard Unix time, so a random number of
seconds since January 1, 1970.

```js
chance.timestamp();
=> 576556683
```
