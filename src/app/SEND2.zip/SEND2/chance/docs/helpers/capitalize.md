# capitalize

```js
// usage
chance.capitalize(string)
```

Capitalize the first letter of a word

```js
chance.capitalize('bread')
=> 'Bread'
```
