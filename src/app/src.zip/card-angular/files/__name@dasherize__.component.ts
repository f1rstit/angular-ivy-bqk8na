import { Component } from '@angular/core';
import { Tile } from '../core/models/Tile';

@Component({
  selector: '<%= dasherize(name) %>',
  templateUrl: './<%= dasherize(name) %>.component.html',
  styleUrls: ['./<%= dasherize(name) %>.component.scss']
})
export class <%= classify(name) %>Component {
	tiles: Tile[] = [
		{text: 'One', color: 'lightblue'},
		{text: 'Two', color: 'lightgreen'},
		{text: 'Three', color: 'lightpink'},
		{text: 'Four', color: '#DDBDF1'},
	  ];
  
  constructor( ) { }

}
