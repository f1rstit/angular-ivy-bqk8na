import { Rule } from '@angular-devkit/schematics';
export default function (options: any): Rule;
