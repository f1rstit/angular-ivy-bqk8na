"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.crudAngular = exports.setupOptions = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const path_1 = require("path");
const workspace_1 = require("@schematics/angular/utility/workspace");
const core_1 = require("@angular-devkit/core");
const JSON5 = require("json5");
const crudModelUtils = require("../utils/crud-model-utils");
const strings_1 = require("@angular-devkit/core/src/utils/strings");
function setupOptions(host, options) {
    return __awaiter(this, void 0, void 0, function* () {
        const workspace = yield workspace_1.getWorkspace(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
        }
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`Invalid project name: ${options.project}`);
        }
        options.path = path_1.join(path_1.normalize(project.root), 'src/app/generate');
        return host;
    });
}
exports.setupOptions = setupOptions;
function crudAngular(_options) {
    return (tree, _context) => __awaiter(this, void 0, void 0, function* () {
        yield setupOptions(tree, _options);
        console.warn("_options", _options);
        const modelFile = `${_options.path}/${_options.model}`;
        console.info("modelFile", modelFile);
        const modelBuffer = tree.read(modelFile);
        console.info("modelBuffer", modelBuffer);
        const modelJson = modelBuffer === null || modelBuffer === void 0 ? void 0 : modelBuffer.toString('utf-8');
        let model;
        if (typeof modelJson !== 'undefined') {
            model = JSON5.parse(modelJson);
        }
        console.info("model", model);
        const movePath = path_1.normalize(_options.path + '/' + strings_1.dasherize(_options.name));
        const templateSource = schematics_1.apply(schematics_1.url('./files'), [
            schematics_1.template(Object.assign(Object.assign(Object.assign(Object.assign({}, core_1.strings), _options), crudModelUtils), { model })),
            schematics_1.move(movePath)
        ]);
        return schematics_1.chain([schematics_1.mergeWith(templateSource, schematics_1.MergeStrategy.Overwrite)]);
    });
}
exports.crudAngular = crudAngular;
//# sourceMappingURL=index.js.map