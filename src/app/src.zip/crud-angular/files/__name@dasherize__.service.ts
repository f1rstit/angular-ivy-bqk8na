import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { <%= classify(name) %>FiltersVM, <%= classify(name) %>VM,<%= classify(name) %>CreateVM,<%= classify(name) %>UpdateVM, <%= classify(name) %>Client
<% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
  ,<%= classify(filter.column1FK) %>Client
<% } %>
  <% if (model.isImport) { %>
  ,Import<%= classify(name) %>FiltersVM
  <% } %>
} from "../core/http/api.client";
import { FilterService, FiltersVM } from "../core/services/filter.service";

@Injectable({
  providedIn: 'root'
})
export class <%= classify(name) %>FilterService extends FilterService<<%= classify(name) %>FiltersVM> {

}

@Injectable({
  providedIn: 'root'
})
export class <%= classify(name) %>Service {
  filters: Observable<FiltersVM<<%= classify(name) %>FiltersVM>>;
  apiFilters: Observable<<%= classify(name) %>FiltersVM>;
  <% if (model.isImport) { %>
  importFilters: Observable<FiltersVM<Import<%= classify(name) %>FiltersVM>>;
  <% } %>
  <%= camelize(name) %>List: Observable<<%= classify(name) %>VM[]>;
  loading = new BehaviorSubject<boolean>(false);
  
  constructor(private filterService: <%= classify(name) %>FilterService,private client: <%= classify(name) %>Client
  <% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
  ,private <%= camelize(filter.column1FK) %>Client: <%= classify(filter.column1FK) %>Client
<% } %>
 <% if (model.isImport) { %>
 ,private importFilterService: FilterService<Import<%= classify(name) %>FiltersVM>
 <% } %>
) { 
	this.filterService.setDefault(this.getDefaultFilter());
	<% if (model.isImport) { %>
	this.importFilterService.setDefault(this.getDefaultImportFilter());
	this.importFilters = this.importFilterService.filters;
	<% } %>
    this.patchFilters({});
    this.apiFilters = this.filterService.apiFilters;
    this.filters = this.filterService.filters;
	}

  get<%= classify(name) %>s(filters: <%= classify(name) %>FiltersVM | null | undefined): Observable<<%= classify(name) %>VM[]> {
    return this.client.getAll(filters);
  }

  get(id:number){
    return this.client.get(id);
  }

  delete(ids:string){
    return this.client.delete(ids);
  }

  mapFilters(filters: FiltersVM<<%= classify(name) %>FiltersVM>) { 
    return this.filterService.mapFilters(filters); 
  }

  private getDefaultFilter(): FiltersVM<<%= classify(name) %>FiltersVM> {
    return {
		<% for (let filter of model.filters) { %>
			<%= classify(filter.column1Name) %>:{ Value: null, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() },
		<% } %>
		Page:{ Value: 1, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() },
        PageSize:{ Value: 25, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() }
    };
  }

  patchFilters(patch: { [K in keyof <%= classify(name) %>FiltersVM]?: Partial<FiltersVM<<%= classify(name) %>FiltersVM>[K]> }) {
    this.filterService.patchFilters(patch);
  }

refresh() { this.filterService.refresh() }

  clearFiltersExcept(keys: (keyof <%= classify(name) %>FiltersVM)[]) {
    this.filterService.clearFiltersExcept(...keys);
  }

  create(<%= camelize(name) %>:<%= classify(name) %>CreateVM){
    return this.client.create(<%= camelize(name) %>);
  }

  update(<%= camelize(name) %>:<%= classify(name) %>UpdateVM){
    return this.client.update(<%= camelize(name) %>);
  }

<% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
  get<%= classify(filter.column1FK) %>s(){
    return this.<%= camelize(filter.column1FK) %>Client.getAll();
  }
<% } %>

<% if (model.isImport) { %>
  mapImportFilters(filters: FiltersVM<Import<%= classify(name) %>FiltersVM>) { 
    return this.importFilterService.mapFilters(filters); 
  }
  
private getDefaultImportFilter(): FiltersVM<Import<%= classify(name) %>FiltersVM> {
    return {
		  Statut_de_validite:{ Value: null, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() }	,
      IsErrorNiveau_hierarchique:{ Value: null, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() }	,
      IsErrorType_de_BU:{ Value: null, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() }	,
      IsError:{ Value: null, TextFr: null, TextEn: null, Show: true, UpdatedDate: new Date() }	
    };
  }
  
  patchImportFilters(patch: { [K in keyof Import<%= classify(name) %>FiltersVM]?: Partial<FiltersVM<Import<%= classify(name) %>FiltersVM>[K]> }) {
    this.importFilterService.patchFilters(patch);
  }
  
  validateImport(){
    return this.client.validateImport();
  }
<% } %>

getAccess(){
    return this.client.getColumnDisplay();
  }

  setDefaultFilters() {
    this.filterService.setDefault(this.getDefaultFilter(), true);
  }

  init(patch: { [K in keyof <%= classify(name) %>FiltersVM]?: Partial<FiltersVM<<%= classify(name) %>FiltersVM>[K]> }) {
    const defaultFilter = this.getDefaultFilter();
    const filter = Object.keys(defaultFilter)
      .map(k => k as keyof FiltersVM<<%= classify(name) %>FiltersVM>)
      .reduce((acc, key) => ({ ...acc, [key]: { ...acc[key], ...patch[key] } }), defaultFilter);
    this.filterService.init(filter);
  }
  
}