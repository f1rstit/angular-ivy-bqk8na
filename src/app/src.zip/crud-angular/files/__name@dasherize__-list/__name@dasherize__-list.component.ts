import { SelectionModel } from '@angular/cdk/collections';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';

import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatAccordion } from '@angular/material/expansion';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { <%= classify(name) %>Service } from '../<%= dasherize(name) %>.service';
import { <%= classify(name) %>VM, <%= classify(name) %>FiltersVM } from 'src/app/core/http/api.client';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { indicate } from 'src/app/core/observable-extensions';
import { FiltersVM } from 'src/app/core/services/filter.service';
import { ConfirmationDialogComponent } from '../../share/components/confirmation-dialog/confirmation-dialog.component';
import * as _ from 'underscore';
import { ContextService } from 'src/app/core/services/context.service';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';

@Component({
  selector: '<%= dasherize(name) %>-list',
  templateUrl: './<%= dasherize(name) %>-list.component.html',
  styleUrls: ['./<%= dasherize(name) %>-list.component.scss'],
})
@UntilDestroy({ checkProperties: true })
export class <%= classify(name) %>ListComponent implements OnInit{
  displayedColumns: string[] = [];

  subscription: Subscription;
  dataSource:MatTableDataSource<<%= classify(name) %>VM>;
  selection = new SelectionModel<<%= classify(name) %>VM>(true, []);
  loading: Subject<boolean> = new BehaviorSubject<boolean>(false);
  
  page = 1;
  pageSize = 25;
  count:number;

  filters:<%= classify(name) %>FiltersVM={
		<% for (let field of model.filters) { %>
			<%= field.column1Name %>:null,
		<% } %>
		Page:null,
		PageSize:null
	  };
  pageSizeOptions: number[] = [5, 10, 25, 50, 100];
 
  pageEvent: PageEvent;

  @ViewChild(MatAccordion)
  accordion!: MatAccordion;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  constructor(private <%= camelize(name) %>Service: <%= classify(name) %>Service,public dialog: MatDialog,private contextService:ContextService) {
      this.dataSource = new MatTableDataSource<<%= classify(name) %>VM>();

    this.<%= camelize(name) %>Service.getAccess()
	.pipe(untilDestroyed(this))
    .subscribe(resp => {
      this.displayedColumns = resp;
    });
   }

   ngOnInit(): void {
	this.subscription = this.<%= camelize(name) %>Service.filters
     .pipe(
       map(filters => this.mapFilters(filters)),
       tap(filters => this.filters = filters),
       switchMap(filters => {
         return this.<%= camelize(name) %>Service.get<%= classify(name) %>s(filters)
           .pipe(indicate(this.loading));
       }))
    .subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      let isRefreshPaginator = !(this.count == data[0]?.Count);
      this.count = data.length > 0 ? data[0].Count : 0;
      if(isRefreshPaginator) this.dataSource.paginator = this.paginator;
     });   
    
    this.<%= camelize(name) %>Service.setDefaultFilters(); 
  }
  
  ngAfterViewInit(){
  this.dataSource.paginator = this.paginator;
}

mapFilters(filters: FiltersVM<<%= classify(name) %>FiltersVM>) {
        return this.<%= camelize(name) %>Service.mapFilters(filters);
  }
  
 updatePagination(event?: PageEvent){
    this.<%= camelize(name) %>Service.patchFilters({
     Page:{Value: event.pageIndex+1}
     ,PageSize:{Value: event.pageSize}
   })
    return event;
  }

  
  refresh(){
    this.<%= camelize(name) %>Service.refresh();
  }

  delete(rowId: string) {
    const dialogConfig = new MatDialogConfig();
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
      value => {
        if (value) {
          this.<%= camelize(name) %>Service.delete(rowId).subscribe(resp => {
            console.warn(resp);
            this.refresh();
            });
          }
        }
    );

  }

  deleteMulti() {
    const dialogConfig = new MatDialogConfig();
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
      value => {
        if (value) {
          const ids = _.pluck(this.selection.selected,'Id').join(",");
          this.<%= camelize(name) %>Service.delete(ids).subscribe(resp => {
            console.warn(resp);
            this.refresh();
            this.selection.clear();
          });
          }
        }
    );
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = !!this.dataSource && this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ? this.selection.clear() : this.dataSource.data.forEach(r => this.selection.select(r));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row: <%= classify(name) %>VM): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.Id}`;
  }
  
  userHasRight(pageName: string,rightName: string){
    return this.contextService.userHasRight(pageName,rightName);
  }
  
  <% for (let fk of model.fields.filter(field => field.isContext)) { %>
  set<%= classify(name) %>(<%= camelize(name) %>Id:number){
    this.contextService.set<%= classify(name) %>Id(<%= camelize(name) %>Id);
  }
  <% } %> 
  
  <% if(model.isCancel){ %>
		cancel(<%= camelize(name) %>Id:number){   
			this.<%= camelize(name) %>Service
				.get(<%= camelize(name) %>Id)
				  .subscribe(resp => {
					  resp.StatutId = 4;
					  this.<%= camelize(name) %>Service
						  .update(resp)
						  .subscribe(
								result=>{
								  console.warn(result);
								  this.refresh();
							  },error =>{
								  console.error(error);
						  });
				});
		  }
  <% } %>
<% if(model.isExport){ %>
export(){
    console.warn('START FUNCTION export()');
  }
  <% } %>

<% if(model.isCreateIf){ %>
isCreate(){
    return <%= model.createIf %>;
  }
<% } %>  
}
