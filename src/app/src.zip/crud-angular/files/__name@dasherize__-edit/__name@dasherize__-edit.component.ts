import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { <%= classify(name) %>VM
<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>
  ,<%= classify(fk.name) %><% if(!fk.isRefFK){ %>VM<% } %>
  	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,<%= classify(fk2.name) %><% if(!fk2.isRefFK){ %>VM<% } %>	
	<% } %>
<% } %>
 } from 'src/app/core/http/api.client';
import { <%= classify(name) %>Service } from '../<%= dasherize(name) %>.service';
import { SuccessSnackbarComponent } from 'src/app/share/components/success-snackbar/success-snackbar.component';
import { ErrorSnackbarComponent } from 'src/app/share/components/error-snackbar/error-snackbar.component';
import { forkJoin } from 'rxjs';
import { ContextService } from 'src/app/core/services/context.service';
import { LocalizationService } from 'src/app/core/services/localization.service';

@Component({
  selector: '<%= dasherize(name) %>-edit',
  templateUrl: './<%= dasherize(name) %>-edit.component.html',
  styleUrls: ['./<%= dasherize(name) %>-edit.component.scss'],
})
export class <%= classify(name) %>EditComponent implements OnInit{
	get localizationProperty() { return this.localizationService.getPropertyName(); }
	
	id: number;
	versionId: number;
	<% for (let field of model.fields.filter(field=>field.isEdit)) { %>
		<% if(field.isFk){ %>
			<%= camelize(field.name) %>Selected:<%= classify(field.propertyType) %><% if(!field.isRefFK){ %>VM<% } %>;
			<% for (let fk of model.fk.filter(fk => fk.name == field.property)) { %>
				<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
				<%= camelize(fk2.columnName) %>Selected:<%= classify(fk2.name) %>;
				<% } %>
			<% } %>			
		<% } else { %>
			<%= camelize(field.name) %>Selected:<%= field.propertyType %>;
		<% } %>			
	<% } %>

<% for (let field of model.fields.filter(field=>field.isEdit)) { %>
	is<%= classify(field.name) %>Disabled = false;
				<% for (let fk of model.fk.filter(fk => fk.name == field.property)) { %>
				<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
				is<%= classify(fk2.columnName) %>Disabled = false;
				<% } %>
			<% } %>		
<% } %>

<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>
	<%= camelize(fk.name) %>s: <%= classify(fk.name) %><% if(!fk.isRefFK){ %>VM<% } %>[] = [];
	<%= camelize(fk.name) %>sAll: <%= classify(fk.name) %><% if(!fk.isRefFK){ %>VM<% } %>[] = [];
  	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
		<%= camelize(fk2.name) %>s: <%= classify(fk2.name) %><% if(!fk2.isRefFK){ %>VM<% } %>[] = [];
	<% } %>
<% } %>

  <%= camelize(name) %>:<%= classify(name) %>VM= {Id:0
<% for (let field of model.fields.filter(field=>!field.isNullable && !field.isKey)) { %>
	,<%= classify(field.name) %>:null
<% } %>
<% for (let fk of model.fk) { %>
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,<%= classify(fk2.columnName) %>:null	
	<% } %>
<% } %>
,Count:null};
  isCreate:boolean;
  durationInSeconds = 5;

  constructor(private route: ActivatedRoute,private <%= camelize(name) %>Service: <%= classify(name) %>Service,private _snackBar: MatSnackBar
  ,private contextService:ContextService
    ,private localizationService :LocalizationService) { }

   ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.isCreate = !this.id;
	this.versionId = this.contextService.VersionId;

	forkJoin({
		<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>		
		<%= camelize(fk.name) %>s: this.<%= camelize(name) %>Service.get<%= classify(fk.name) %>s(),
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>				
			<%= camelize(fk2.name) %>s: this.<%= camelize(name) %>Service.get<%= classify(fk2.name) %>s(),
			<% } %>
		<% } %>
	})
	  .subscribe(({
		<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>		
		<%= camelize(fk.name) %>s,
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>				
			<%= camelize(fk2.name) %>s,
			<% } %>
		<% } %>

		}) => {
		<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>		
		this.<%= camelize(fk.name) %>s = <%= camelize(fk.name) %>s;
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>				
			this.<%= camelize(fk2.name) %>s = <%= camelize(fk2.name) %>s;
			<% } %>
		<% } %>

    if(!this.isCreate)
    this.<%= camelize(name) %>Service.get(this.id).subscribe(resp => {
      this.<%= camelize(name) %> = resp;
	  
	<% for (let field of model.fields.filter(field => field.isEdit && field.isReadOnly)) { %>
	this.is<%= classify(field.name) %>Disabled = true;
	<% } %> 
	  		<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>		
		this.<%= camelize(fk.name) %>IdSelected = this.<%= camelize(fk.name) %>s.find(i=> i.Id == this.<%= camelize(name) %>.<%= classify(fk.name) %>Id);
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>				
			this.<%= camelize(fk2.name) %>IdSelected = this.<%= camelize(fk2.name) %>s.find(i=> i.Id == this.<%= camelize(name) %>.<%= classify(fk2.name) %>Id);
			<% } %>
		<% } %>
  });
    });
   }

 save(){
	 <% for (let field of model.fields.filter(field => field.isEdit)) { %>
	 <% if(field.isFk){ %>
	 this.<%= camelize(name) %>.<%= classify(field.name) %> = this.<%= camelize(field.name) %>Selected.Id;
	 <% } else if(field.typescript == "Date") { %>
	 this.<%= camelize(name) %>.<%= classify(field.name) %> = new Date(this.<%= camelize(name) %>.<%= classify(field.name) %>.getTime() - this.<%= camelize(name) %>.<%= classify(field.name) %>.getTimezoneOffset()*60000);
	 <% } %>
  <% } %> 
  
  if(this.isCreate)
  this.<%= camelize(name) %>Service
  .create(this.<%= camelize(name) %>)
  .subscribe(result=>{
    console.warn(result);
    this._snackBar.openFromComponent(SuccessSnackbarComponent, {
      duration: this.durationInSeconds * 1000,
    });
  }
    , error =>{
      console.error(error);
      this._snackBar.openFromComponent(ErrorSnackbarComponent, {
        duration: this.durationInSeconds * 1000,
      });
    });
  else
  this.<%= camelize(name) %>Service
  .update(this.<%= camelize(name) %>)
  .subscribe(result=>{
    console.warn(result);
    this._snackBar.openFromComponent(SuccessSnackbarComponent, {
      duration: this.durationInSeconds * 1000,
    });
  }, error =>{
    console.error(error);
    this._snackBar.openFromComponent(ErrorSnackbarComponent, {
      duration: this.durationInSeconds * 1000,
    });
  }
  
  );

 }


	// <% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>		
		<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	 on<%= classify(fk2.columnName) %>Change(){
		if(this.<%= camelize(fk2.columnName) %>Selected)
			this.<%= camelize(fk.name) %>s = this.<%= camelize(fk.name) %>sAll.filter(<%= camelize(fk.name) %> => <%= camelize(fk.name) %>.<%= classify(fk2.columnName) %> == this.<%= camelize(fk2.columnName) %>Selected.Id);
		else
			this.<%= camelize(fk.name) %>s = this.<%= camelize(fk.name) %>sAll;

		this.<%= camelize(fk.columnName) %>Selected = this.<%= camelize(fk.name) %>s.find(i=> i.Id == this.<%= camelize(fk.columnName) %>Selected?.Id);
	  }
		<% } %>
	<% } %>
		
		
}
