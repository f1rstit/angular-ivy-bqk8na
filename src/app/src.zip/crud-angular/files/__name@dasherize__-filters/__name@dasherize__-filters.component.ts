import { Component, OnInit } from '@angular/core';
import { <%= classify(name) %>FiltersVM
<% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
  ,<%= classify(filter.column1FK) %><% if(!filter.isRefFK){ %>VM<% } %>
<% } %>
  } from 'src/app/core/http/api.client';
import { <%= classify(name) %>Service } from '../<%= dasherize(name) %>.service';
import * as _ from 'underscore';
import { LocalizationService } from 'src/app/core/services/localization.service';
import { Observable } from 'rxjs';

@Component({
  selector: '<%= dasherize(name) %>-filters',
  templateUrl: './<%= dasherize(name) %>-filters.component.html',
  styleUrls: ['./<%= dasherize(name) %>-filters.component.scss']
})
export class <%= classify(name) %>FiltersComponent implements OnInit {
	get localizationProperty() { return this.localizationService.getPropertyName(); }
<% for (let filter of model.filters.filter(filter => filter.column1FK != "Version")) { %>
	<%= camelize(filter.column1Name) %>Selected:<%= !!filter.column1FK ? filter.column1FK : filter.typescript %><% if(!!filter.column1FK && !filter.isRefFK){ %>VM<% } %>;
<% } %>

<% for (let filter of model.filters) { %>
	is<%= classify(filter.column1Name) %>Disabled = false;
<% } %>
<% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
	<% if(filter.isParent){ %>
		<%= camelize(filter.column1FK) %>s$: Observable<<%= classify(filter.column1FK) %>[]>;
	<% } else { %>	
		<%= camelize(filter.column1FK) %>s: <%= classify(filter.column1FK) %><% if(!filter.isRefFK){ %>VM<% } %>[] = [];
		<%= camelize(filter.column1FK) %>sAll: <%= classify(filter.column1FK) %><% if(!filter.isRefFK){ %>VM<% } %>[] = [];
	<% } %>		
<% } %>

  constructor(private <%= camelize(name) %>Service: <%= classify(name) %>Service, private localizationService: LocalizationService) { }

  ngOnInit() {
	  <% for (let filter of model.filters.filter(filter => filter.name =="select" || filter.name =="selectMulti")) { %>
		  <% if(filter.isParent){ %>
		  this.<%= camelize(filter.column1FK) %>s$ = this.<%= camelize(name) %>Service.get<%= classify(filter.column1FK) %>s();
		  <% } else { %>	
		  this.<%= camelize(name) %>Service.get<%= classify(filter.column1FK) %>s()
			.subscribe(<%= camelize(filter.column1FK) %>s => {
				this.<%= camelize(filter.column1FK) %>sAll = <%= camelize(filter.column1FK) %>s;
				this.<%= camelize(filter.column1FK) %>s = <%= camelize(filter.column1FK) %>s;
			});
		  <% } %>		  
	<% } %>
  }

	<% for (let filter of model.filters.filter(filter => filter.column1FK != "Version")) { %>
	on<%= classify(filter.column1Name) %>Change(){
		
		<% for (let fk of model.fk.filter(fk => fk.name !="Version")) { %>
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut" && fk2.name == filter.column1FK)) { %>	
			if(this.<%= camelize(filter.column1Name) %>Selected)
				this.<%= camelize(fk.name) %>s = this.<%= camelize(fk.name) %>sAll.filter(bl => bl.OpId == this.<%= camelize(filter.column1Name) %>Selected.Id);
			else
				this.<%= camelize(fk.name) %>s = this.<%= camelize(fk.name) %>sAll;
			<% } %>
		<% } %>
		
		this.<%= camelize(name) %>Service.patchFilters({
			<%= classify(filter.column1Name) %>:{
			Value:  <% if(filter.name == "selectMulti"){ %>
				_.pluck(this.<%= camelize(filter.column1Name) %>Selected,'Id').join(",")
					<% } else { %>
					this.<%= camelize(filter.column1Name) %>Selected<% if(filter.name == "select"){ %>?.Id<% } %>
					<% } %>			
			},
			Page:{
			Value: 1
			}
		});
	  }
	<% } %>

  clear() {
	<% for (let filter of model.filters.filter(filter => filter.column1FK != "Version")) { %>
		this.<%= camelize(filter.column1Name) %>Selected = null;
	<% } %>
    const keys: (keyof <%= classify(name) %>FiltersVM)[] = ["Page","PageSize"]
    this.<%= camelize(name) %>Service.clearFiltersExcept(keys);
  }

}