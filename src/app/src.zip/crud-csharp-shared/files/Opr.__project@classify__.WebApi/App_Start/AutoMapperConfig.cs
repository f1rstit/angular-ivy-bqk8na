using AutoMapper;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.Domain.ViewModels;

namespace Opr.<%= classify(project) %>.WebApi.App_Start
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
			<% for (const entity of model.models) { %>
			CreateMap<<%= classify(entity.name) %>, <%= classify(entity.name) %>VM>()
			<% for (const fk of entity.fk) { %>
			.ForMember(dest => dest.<%= classify(fk.name) %>Name,
                            opt => opt.MapFrom(src => src.<%= classify(fk.name) %>.Name))
			<%  } %>
                .ReverseMap(); 
            <%  } %>
			
            
        }

    }
}
