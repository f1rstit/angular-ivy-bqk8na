using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Opr.<%= classify(project) %>.Business.Contracts;
using Opr.<%= classify(project) %>.Business.Core;
using Opr.<%= classify(project) %>.Business.Services;
using Opr.<%= classify(project) %>.Data;
using Opr.<%= classify(project) %>.Data.Contracts;
using Opr.<%= classify(project) %>.Data.Core;
using Opr.<%= classify(project) %>.Data.Repositories;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.WebApi.Filters;

namespace Opr.<%= classify(project) %>.WebApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
			services.AddAutoMapper(typeof(Startup));
            services
                .AddControllers(options => {
                options.Filters.Add(typeof(UnitOfWorkFilter));
                }).AddJsonOptions(options =>
                {
                    options.JsonSerializerOptions.PropertyNamingPolicy = null;
                });

            services.AddDbContext<ApplicationDbContext>(opts => opts.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

			services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            services.AddSwaggerDocument();
            services.AddScoped<IUnitOfWork, UnitOfWork>();
			services.AddScoped<IKeyValueService, KeyValueService>();
            services.AddScoped<IFileService, FileService>();
            services.AddScoped<IExportService, ExportService>();
			
            <% for (const entity of model.models) { %>           
				<% if (!entity.isRef) { %>services.AddScoped<I<%= classify(entity.name) %>Repository, <%= classify(entity.name) %>Repository>();<% } %>
				services.AddScoped<IRepository<<%= classify(entity.name) %>>, RepositoryEntity<<%= classify(entity.name) %>>>();   
				services.AddScoped<I<%= classify(entity.name) %>Service, <%= classify(entity.name) %>Service>();
            <%  } %>

            

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

			if (env.IsDevelopment())
            {
                app.UseOpenApi();
                app.UseSwaggerUi3();
            }
			
            app.UseRouting();

            app.UseAuthorization();

            app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
