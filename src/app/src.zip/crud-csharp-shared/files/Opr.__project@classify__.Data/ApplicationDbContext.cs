﻿using Microsoft.EntityFrameworkCore;
using Opr.<%= classify(project) %>.Domain.Entities;

namespace Opr.<%= classify(project) %>.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public ApplicationDbContext() { }
		
		<% for (const entity of model.models) { %>
				
		public DbSet<<%= classify(entity.name) %>> <%= classify(entity.name) %>s { get; set; }
			
		<%  } %>	 
		public DbSet<UserDto> UserDtos { get; set; }
		public DbSet<MappingBLbyOEDto> MappingBLbyOEDtos { get; set; }
    }
}
