/// <reference types="cypress" />
import { steps } from "../../../fixtures/<%= name %>.data.json";

describe("<%= model.title %>", () => {
	
	<% for (const [i,step] of model.steps.entries()) { %>
	it("<%= step.name %>", () => {
		cy.<%= step.code %>;
	});
	<% } %>
	
});