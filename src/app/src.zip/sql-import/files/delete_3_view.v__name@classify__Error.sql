DROP VIEW [gaporg].[v_<%= classify(name) %>Error]
GO