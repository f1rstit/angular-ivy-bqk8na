use [Planet]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [gaporg].[v_<%= classify(name) %>Error]
AS
SELECT 
<% for (const [i,field] of model.fields.filter(field=>!field.isKey).entries()) { %>
	MAX(<%= field.name %>) AS <%= field.name %>
	, MAX(<%= field.name %>_Message) AS <%= field.name %>_Message
	<% if(i+1<model.fields.filter(field=>!field.isKey).length){ %>, <% } %>
<% } %>

FROM   (SELECT RowNumber

<% for (let field of model.fields.filter(field=>!field.isKey)) { %>
, CASE WHEN [Column] = '<%= field.name %>' THEN RowNumber ELSE NULL END AS <%= field.name %>
, CASE WHEN [Column] = '<%= field.name %>' THEN [Message] ELSE NULL END AS <%= field.name %>_Message
<% } %>

             FROM    gaporg.UploadFileError) AS temp
GROUP BY RowNumber