import { Rule, Tree } from '@angular-devkit/schematics';
export declare function setupOptions(host: Tree, options: any): Promise<Tree>;
export declare function sqlImport(_options: any): Rule;
