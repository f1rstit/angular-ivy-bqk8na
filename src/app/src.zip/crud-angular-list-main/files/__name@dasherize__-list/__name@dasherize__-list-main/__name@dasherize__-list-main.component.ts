import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';

import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatAccordion } from '@angular/material/expansion';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { <%= classify(name) %>Service } from '../../<%= dasherize(name) %>.service';
import { <%= classify(name) %>VM, <%= classify(name) %>FiltersVM} from 'src/app/core/http/api.client';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { indicate } from 'src/app/core/observable-extensions';
import { FiltersVM, FilterVM } from 'src/app/core/services/filter.service';
import * as _ from 'underscore';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';

@Component({
  selector: '<%= dasherize(name) %>-list-main',
  templateUrl: './<%= dasherize(name) %>-list-main.component.html',
  styleUrls: ['./<%= dasherize(name) %>-list-main.component.scss'],
})
@UntilDestroy({ checkProperties: true }) 
export class <%= classify(name) %>ListMainComponent implements OnInit{
  public response: {isSuccess: false};

  displayedColumns: string[] = [  
  <% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
  '<%= field.name %>',
  <% } %>
  
'versionName'];

  subscription: Subscription;
  dataSource:MatTableDataSource<<%= classify(name) %>VM>;
  selection = new SelectionModel<<%= classify(name) %>VM>(true, []);
  loading: Subject<boolean> = new BehaviorSubject<boolean>(false);
   
  page = 1;
  pageSize = 20;
  count = 100;

  filters:<%= classify(name) %>FiltersVM={	
  <% for (let field of model.fields.filter(field=>!field.isKey && field.isFilter)) { %>
			<%= field.name %>:<% if(field.isFk){ %>null<% } else { %>""<% } %>,
		<% } %>
  };
  pageSizeOptions: number[] = [5, 10, 25, 100];
 
  pageEvent: PageEvent;

  @ViewChild(MatAccordion)
  accordion!: MatAccordion;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(private <%= camelize(name) %>Service: <%= classify(name) %>Service,public dialog: MatDialog) {
      console.warn('START <%= classify(name) %>ListMainComponent.constructor()');
	  this.dataSource = new MatTableDataSource<<%= classify(name) %>VM>();

    this.<%= camelize(name) %>Service.getAccess()
    .subscribe(resp => {
      this.displayedColumns = resp;
    });
   }

   ngOnInit(): void {
	this.subscription = this.<%= camelize(name) %>Service.filters
     .pipe(
       map(filters => this.mapFilters(filters)),
       tap(filters => this.filters = filters),
       switchMap(filters => {
         this.page = 1;
         return this.<%= camelize(name) %>Service.get<%= classify(name) %>s(filters)
           .pipe(indicate(this.loading));
       }))
    .subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      let isRefreshPaginator = !(this.count == data[0]?.Count);
      this.count = data.length > 0 ? data[0].Count : 0;
      if(isRefreshPaginator) this.dataSource.paginator = this.paginator;
     });   
    
     this.<%= camelize(name) %>Service.setDefaultFilters(); 
  }
  
    ngAfterViewInit(){
  this.dataSource.paginator = this.paginator;
  this.dataSource.sort = this.sort;
}

mapFilters(filters: FiltersVM<<%= classify(name) %>FiltersVM>) {
        return this.<%= camelize(name) %>Service.mapFilters(filters);
  }
  
 updatePagination(event?: PageEvent){
    this.<%= camelize(name) %>Service.patchFilters({
     Page:{Value: event.pageIndex+1}
     ,PageSize:{Value: event.pageSize}
   })
    return event;
  }

  
  refresh(){
    this.<%= camelize(name) %>Service.refresh();
  }

}
