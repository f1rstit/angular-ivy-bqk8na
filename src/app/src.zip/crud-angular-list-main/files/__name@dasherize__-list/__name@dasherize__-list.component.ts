import { Component } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { <%= classify(name) %>Service } from '../<%= dasherize(name) %>.service';

@Component({
  selector: '<%= dasherize(name) %>-list',
  templateUrl: './<%= dasherize(name) %>-list.component.html',
  styleUrls: ['./<%= dasherize(name) %>-list.component.scss'],
})
export class <%= classify(name) %>ListComponent{
  isImport:boolean = false;
  isImportSuccess:boolean = false;
  uploadFileTypeId:number = 4;

  constructor(private cookieService: CookieService,private <%= camelize(name) %>Service: <%= classify(name) %>Service) { }

  public uploadFinished = (event:any) => {
    this.isImport = true;
    this.cookieService.get('isImportSuccess');
    this.isImportSuccess = this.cookieService.get('isImportSuccess') === "1";
  }

  validate(){
    this.<%= camelize(name) %>Service.validateImport()
    .subscribe(resp => {
      this.isImport = false;
    });
  }
}