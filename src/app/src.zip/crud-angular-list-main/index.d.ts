import { Rule, Tree } from '@angular-devkit/schematics';
export declare function setupOptions(host: Tree, options: any): Promise<Tree>;
export declare function crudAngularListMain(_options: any): Rule;
