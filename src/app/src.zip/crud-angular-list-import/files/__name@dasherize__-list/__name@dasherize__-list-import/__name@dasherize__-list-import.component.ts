import { SelectionModel } from '@angular/cdk/collections';
import { Component, OnInit, ViewChild } from '@angular/core';

import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatAccordion } from '@angular/material/expansion';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { <%= classify(name) %>Service } from '../../<%= dasherize(name) %>.service';
import { Import<%= classify(name) %>Client,Import<%= classify(name) %>VM, Import<%= classify(name) %>FiltersVM, <%= classify(name) %>FiltersVM } from 'src/app/core/http/api.client';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { indicate } from 'src/app/core/observable-extensions';
import { FiltersVM, FilterVM } from 'src/app/core/services/filter.service';
import * as _ from 'underscore';

export type FilterBadgeVM = FilterVM<any> & { Property: keyof <%= classify(name) %>FiltersVM }

@Component({
  selector: '<%= dasherize(name) %>-list-import',
  templateUrl: './<%= dasherize(name) %>-list-import.component.html',
  styleUrls: ['./<%= dasherize(name) %>-list-import.component.scss'],
})
export class <%= classify(name) %>ListImportComponent implements OnInit{
	public response: {isSuccess: false};
  displayedColumns: string[] = [
  <% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
  '<%= removeAccent(field.name) %>',
  <% } %>
  ];

  subscription: Subscription;
  dataSource:MatTableDataSource<Import<%= classify(name) %>VM>;
  selection = new SelectionModel<Import<%= classify(name) %>VM>(true, []);
  loading: Subject<boolean> = new BehaviorSubject<boolean>(false);
   
  page = 1;
  pageSize = 20;
  count = 100;

  importFilters:Import<%= classify(name) %>FiltersVM[]=[{
		<% for (let field of model.fields.filter(field=>!field.isKey && field.isFilter)) { %>
			<%= removeAccent(field.name) %>:<% if(field.isFk){ %>null<% } else { %>""<% } %>,
		<% } %>
	  }];
  pageSizeOptions: number[] = [5, 10, 25, 100];
 
  pageEvent: PageEvent;

  @ViewChild(MatAccordion)
  accordion!: MatAccordion;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor(private <%= camelize(name) %>Service: <%= classify(name) %>Service,public dialog: MatDialog,private import<%= classify(name) %>Client: Import<%= classify(name) %>Client) {
      
   }

   ngOnInit(): void {
	this.subscription = this.<%= camelize(name) %>Service.importFilters
     .pipe(
       map(filters => this.mapFilters(filters)),
       tap(filters => this.importFilters = [filters]),
       switchMap(filters => {
         this.page = 1;
         return this.import<%= classify(name) %>Client.getAll(this.importFilters, this.page, this.pageSize)
           .pipe(indicate(this.loading));
       }))
    .subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
     });   
    
    this.import<%= classify(name) %>Client
        .getAll(this.importFilters, this.page, this.pageSize)
        .subscribe(resp => {
      this.dataSource = new MatTableDataSource(resp);
	  this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
      console.warn(resp);
    });
  }
  
mapFilters(importFilters: FiltersVM<Import<%= classify(name) %>FiltersVM>) {
        return this.<%= camelize(name) %>Service.mapImportFilters(importFilters);
  }
  
 updatePagination(event?: PageEvent){
    this.page = event.pageIndex+1;
    this.pageSize = event.pageSize;
    this.refresh();
    return event;
  }

  
  refresh(){/*
    this.<%= camelize(name) %>Service
    .get<%= classify(name) %>s(this.filters, this.page, this.pageSize)
    .subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
    });*/
  }

public uploadFinished = (event:any) => {
    this.response = event;
    this.import<%= classify(name) %>Client.getAll(this.importFilters, this.page, this.pageSize).subscribe(data=>{
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
}
