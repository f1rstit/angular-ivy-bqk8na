import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <div id="material-crud">
      <div class="card">
        <div class="content">
<% for (const entity of model.models.filter(entity => entity.name = "version")) { %>
<a routerLink="<%= dasherize(entity.name) %>"><%= classify(entity.name) %></a> |
<% } %>
        </div>
      </div>
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [`
    #material-crud { border: darkred dashed 5px; padding: 10px }
  `],
})
export class CoreComponent {
}
