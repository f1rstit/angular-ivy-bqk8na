import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { createCustomElement } from '@angular/elements';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';

import { MatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar'; 
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSelectModule } from '@angular/material/select';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';

import { MY_DATE_FORMATS } from './core/my-date-formats';
import { UnauthorizedComponent } from './service-pages/unauthorized.component';

<% for (const entity of model.models.filter(entity=>!entity.isRef && entity.isFront && !entity.name.match(/^Import.*$/))) { %>
		<% if (!entity.isImport) { %>import { <%= classify(entity.name) %>EditComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-edit/<%= dasherize(entity.name) %>-edit.component';<% } else { %>
		import { <%= classify(entity.name) %>ListMainComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-list/<%= dasherize(entity.name) %>-list-main/<%= dasherize(entity.name) %>-list-main.component';
		import { <%= classify(entity.name) %>ListImportComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-list/<%= dasherize(entity.name) %>-list-import/<%= dasherize(entity.name) %>-list-import.component';
		<% } %>
		import { <%= classify(entity.name) %>ListComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-list/<%= dasherize(entity.name) %>-list.component';
		import { <%= classify(entity.name) %>Component } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>.component';
		import { <%= classify(entity.name) %>DashboardComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-dashboard/<%= dasherize(entity.name) %>-dashboard.component';
		import { <%= classify(entity.name) %>FiltersComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-filters/<%= dasherize(entity.name) %>-filters.component';
 <% } %>
 
 import { 
  FileClient,
 <% for (const entity of model.models) { %>
 <%= classify(entity.name) %>Client,
 <% } %>
 API_BASE_URL
 } from './core/http/api.client';

import { environment } from '@env/environment';
import { AppComponent } from './app.component';
import { EmptyComponent } from './empty/empty.component';
import { CoreComponent } from './core/core.component';
import { AppRoutingModule } from './app-routing.module';
import { ShareModule } from './share/share.module';
import { MenuVersionComponent } from './menu-version/menu-version.component';
import { MenuUploadComponent } from './menu-upload/menu-upload.component';
import { MenuMappingComponent } from './menu-mapping/menu-mapping.component';
import { FileService } from './core/services/file.service';
import { InitializeProvider } from './core/providers/initialize.provider';
import { HttpRequestInterceptor } from './core/http/htttpinterceptor';
import { LoginComponent } from './login/login.component';

const modules = [
  MatFormFieldModule, 
  MatGridListModule,
  MatPaginatorModule,
  MatTableModule,
  MatInputModule,
  MatCardModule,
  MatIconModule,
  MatToolbarModule,
  MatCheckboxModule,
  MatExpansionModule,
  MatSelectModule,
  MatSortModule,
  MatDialogModule,
  MatSnackBarModule,
  MatTooltipModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatRadioModule
];

@NgModule({
  declarations: [
    AppComponent,EmptyComponent,CoreComponent
	,MenuVersionComponent
	,MenuUploadComponent
	,MenuMappingComponent
	, LoginComponent
	 ,UnauthorizedComponent
    <% for (const entity of model.models.filter(entity=>!entity.isRef && entity.isFront && !entity.name.match(/^Import.*$/))) { %>
      ,<%= classify(entity.name) %>ListComponent
	  <% if (!entity.isImport) { %>,<%= classify(entity.name) %>EditComponent<% } else { %>
	  ,<%= classify(entity.name) %>ListMainComponent
	  ,<%= classify(entity.name) %>ListImportComponent
	  <% } %>
	  ,<%= classify(entity.name) %>Component
	  ,<%= classify(entity.name) %>FiltersComponent
	  ,<%= classify(entity.name) %>DashboardComponent
       <% } %>
  ],
  imports: [
    BrowserModule,modules,
    AppRoutingModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    FormsModule,
    HttpClientModule,
    NgSelectModule,
    ShareModule
  ],
  exports: [ ],
  providers: [
  { provide: MAT_DATE_LOCALE, useValue: 'fr-FR' },
  { provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS },
  { provide: FileClient},
  FileService,
      <% for (const entity of model.models) { %>
	  { provide: <%= classify(entity.name) %>Client},
       <% } %>
	   InitializeProvider,
	   { provide: APP_INITIALIZER, useFactory: initializeAppFactory, deps:[InitializeProvider],multi:true},
	   { provide: API_BASE_URL, useValue: environment.API_BASE_URL },
	   { provide: HTTP_INTERCEPTORS, useClass: HttpRequestInterceptor, multi: true }
	   ],
  bootstrap: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [AppComponent],
})

export class AppModule { 
  constructor(private injector: Injector) {  }

  ngDoBootstrap() {
    console.warn("START AppModule.ngDoBootstrap()");
    const appElement = createCustomElement(AppComponent, { injector: this.injector})
    customElements.define('gaporg-app', appElement);
  }
}

export function initializeAppFactory(provider: InitializeProvider){
	return ()=> provider.load();
}