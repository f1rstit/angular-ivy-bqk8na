import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoreComponent } from './core/core.component';
import { EmptyComponent } from './empty/empty.component';
import { MenuVersionComponent } from './menu-version/menu-version.component';
import { MenuUploadComponent } from './menu-upload/menu-upload.component';
import { MenuMappingComponent } from './menu-mapping/menu-mapping.component';
import { RoleTypeEnum } from './core/http/api.client';
import { RoleGuard } from './core/guards/role.guard';
import { LoginComponent } from './login/login.component';
import { UnauthorizedComponent } from './service-pages/unauthorized.component';

<% for (const entity of model.models.filter(entity=>!entity.isRef && entity.isFront && !entity.name.match(/^Import.*$/))) { %>
		<% if (!entity.isImport) { %>import { <%= classify(entity.name) %>EditComponent } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>-edit/<%= dasherize(entity.name) %>-edit.component';<% } %>
		import { <%= classify(entity.name) %>Component } from './<%= dasherize(entity.name) %>/<%= dasherize(entity.name) %>.component';
<% } %>


const routes: Routes = [
  { path: 'gaporg', component: CoreComponent, 
  children: [
  { path: 'login', component: LoginComponent },
		{path: 'unauthorized', component: UnauthorizedComponent },
	  { path: 'version/:versionId', component: MenuVersionComponent },
      { path: 'version/:versionId/menu-upload', component: MenuUploadComponent },
      { path: 'version/:versionId/menu-mapping', component: MenuMappingComponent },
    <% for (const entity of model.models.filter(entity=>!entity.name.match(/^Import.*$/))) { %>
		<% if (!entity.isRef && entity.isFront && !entity.isImport && !entity.name.match(/^Mapping.*$/)) { %>
			{ path: '<%= dasherize(entity.name) %>', component: <%= classify(entity.name) %>Component, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
			{ path: '<%= dasherize(entity.name) %>/add', component: <%= classify(entity.name) %>EditComponent, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
			{ path: '<%= dasherize(entity.name) %>/edit<% for (const key of entity.keys) { %>/:<%= camelize(key.name) %><% } %>', component: <%= classify(entity.name) %>EditComponent, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
		<% } %>
		<% if (entity.isImport) { %>
		{ path: 'version/:versionId/menu-upload/<%= dasherize(entity.name) %>', component: <%= classify(entity.name) %>Component, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
		<% } %>
		<% if (entity.name.match(/^Mapping.*$/)) { %>
		{ path: 'version/:versionId/menu-mapping/<%= dasherize(entity.name) %>', component: <%= classify(entity.name) %>Component, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
		{ path: 'version/:versionId/menu-mapping/<%= dasherize(entity.name) %>/add', component: <%= classify(entity.name) %>EditComponent, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
		{ path: 'version/:versionId/menu-mapping/<%= dasherize(entity.name) %>/edit<% for (const key of entity.keys) { %>/:<%= camelize(key.name) %><% } %>', component: <%= classify(entity.name) %>EditComponent, canActivate:[RoleGuard],data: { roles:[RoleTypeEnum.SuperAdministrator] }  },
		<% } %>
	<% } %>
    { path: 'mapping-bu-cp', component: EmptyComponent },
  ]},
  { path: '**', component: EmptyComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
