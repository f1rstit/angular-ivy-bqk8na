"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.oprSchematic = void 0;
// You don't have to export the function as default. You can also have more than one rule factory
// per file.
function oprSchematic(_options) {
    return (tree, _context) => {
        return tree;
    };
}
exports.oprSchematic = oprSchematic;
//# sourceMappingURL=index.js.map