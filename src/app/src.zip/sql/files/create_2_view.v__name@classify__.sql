use [Planet]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [gaporg].[v_<%= classify(name) %>]
AS
SELECT [<%= name %>].[Id]
<% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
,[<%= field.source %>].[<%= field.name %>] as '<%= removeAccent(field.name) %>'
<% } %>
<% for (let field of model.fields.filter(field=>field.isFk)) { %>
,[<%= field.property %>].[Id] as '<%= removeAccent(field.name) %>'
<% } %>

<% for (let fk of model.fk) { %>
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,[<%= fk2.name %>].[Id] as '<%= removeAccent(fk2.columnName) %>'
	<% } %>
<% } %>


,[<%= name %>].[SysInsertDateTime]
,[<%= name %>].[SysInsertUserId]
,[<%= name %>].[SysUpdateDateTime]
,[<%= name %>].[SysUpdateUserId]

<% for (let fk of model.fk) { %>
	<% for (let field of fk.fields.filter(field=> field.isShow && !field.isKey)) { %>
	,[<%= fk.name %>].[<%= field.name %>] as '<%= fk.name %><%= removeAccent(field.name) %>'
	<% } %>
	
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
		<% for (let field2 of fk2.fields.filter(field=> field.isShow && !field.isKey)) { %>
		,[<%= fk2.name %>].[<%= field2.name %>] as '<%= fk2.name %><%= removeAccent(field2.name) %>'
		<% } %>
	<% } %>
	
<% } %>


FROM   [<%= model.schema %>].[<%= model.tableName %>] [<%= name %>]

<% for (let fk of model.fk) { %>
	LEFT OUTER JOIN [gaporg].[<%= fk.tableName %>] [<%= fk.name %>] ON [<%= name %>].<%= fk.columnName %> = [<%= fk.name %>].Id
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
		LEFT OUTER JOIN [gaporg].[<%= fk2.tableName %>] [<%= fk2.name %>] ON [<%= fk.name %>].<%= fk2.columnName %> = [<%= fk2.name %>].Id
	<% } %>
<% } %>