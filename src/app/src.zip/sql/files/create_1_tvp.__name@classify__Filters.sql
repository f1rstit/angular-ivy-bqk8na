use [Planet]
GO

CREATE TYPE [gaporg].[<%= classify(name) %>Filters] AS TABLE(
<% for (const [i,field] of model.filters.entries()) { %>
[<%= removeAccent(field.column1Name) %>] <%= field.sqltype %> NULL<% if(i+1<model.filters.length){ %>, <% } %>
<% } %>
)
GO