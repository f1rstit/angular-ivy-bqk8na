USE [Planet]
GO
/****** Object:  StoredProcedure [gaporg].[pMerge_<%= classify(name) %>]    Script Date: 19/08/2021 19:04:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [gaporg].[pMerge_<%= classify(name) %>]
	-- Add the parameters for the stored procedure here
	@pVersionId int=1,
	@pUserLogId int=null,
	@pDebug bit=1

WITH RECOMPILE
AS
BEGIN
begin try

	DECLARE @vStartTime datetime = GETDATE()
	DECLARE @vRowCount INT=0
	DECLARE @vCommand NVARCHAR(MAX)

set @vCommand='EXEC [gaporg].[pMerge_<%= classify(name) %>] @pVersionId='+ cast(@pVersionId as varchar)+',@pDebug='+ cast(@pDebug as varchar)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--------------------------------------
-- 1 - SOURCE FOR MERGE - NEW VERSION OF METADATA
--------------------------------------
SELECT 

<% for (let field of model.fields.filter(field=> !field.isKey)){ %>		
		public <%= field.ctype %><% if(field.ctype=="int"){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }			  
<%  } %>	
  
INTO #Source
FROM [gaporg].[v_<%= classify(name) %>]

IF(@pDebug=1) select * from #Source
--------------------------------------
-- 2 - TARGET FOR MERGE - SCOPE LES LIGNES ACTIVES
--------------------------------------
;WITH CTE_target AS (
           SELECT *
           FROM[gaporg].[<%= classify(name) %>]
)
--------------------------------------
-- 3 - MERGE
--------------------------------------
  MERGE INTO CTE_target AS target
  USING #Source AS source
      ON target.Id = source.Id 
	  WHEN MATCHED 
THEN UPDATE SET 
<% for (const [i,field]  of model.fields.filter(field=> !field.isKey && field.source==name).entries()){ %>		
			target.[<%= removeAccent(field.name) %> ] = source.[<%= removeAccent(field.name) %> ]		 <% if(i+1<model.fields.filter(field=> !field.isKey && field.source==name).length){ %>, <% } %>  
<%  } %>	
  WHEN NOT MATCHED BY TARGET
    THEN INSERT
           (
<% for (const [i,field] of model.fields.filter(field=> !field.isKey && field.source==name).entries()){ %>		
			[<%= removeAccent(field.name) %> ] <% if(i+1<model.fields.filter(field=> !field.isKey && field.source==name).length){ %>, <% } %>  
<%  } %>	
			)
    VALUES
    ( 
	<% for (const [i,field] of model.fields.filter(field=> !field.isKey && field.source==name).entries()){ %>		
			source.[<%= removeAccent(field.name) %> ] <% if(i+1<model.fields.filter(field=> !field.isKey && field.source==name).length){ %>, <% } %>  
<%  } %>	
)
             WHEN NOT MATCHED BY SOURCE
    THEN DELETE output $action AS ActionType,inserted.*,deleted.*;

			 	 end try
	begin catch
	DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

		SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

			exec utility.pA_LogProc
			 @pObjectID       = @@PROCID,
			 @pUserLogId	  = @pUserLogId,
			 @pRowCount		  = @vRowCount,
			 @pCommand		  = @vCommand,
			 @pStartTime      = @vStartTime,
			 @ErrorMessage = @ErrorMessage,
            @ErrorSeverity = @ErrorSeverity,
            @ErrorState = @ErrorState;

RAISERROR (@ErrorMessage, -- Message text.
                   @ErrorSeverity, -- Severity.
                   @ErrorState -- State.
                   );
		RETURN
end catch

	IF(@pDebug=1)	
exec utility.pA_LogProc
 @pObjectID       = @@PROCID,
 @pUserLogId	  = @pUserLogId,
 @pRowCount		  = @vRowCount,
 @pCommand		  = @vCommand,
 @pStartTime      = @vStartTime;

END
