USE [Planet]
GO
DROP VIEW [gaporg].[v_<%= classify(name) %>]
GO