Use Planet
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
<% if (model.isLoginFilter) { %>
declare	@pLoginFilters [gaporg].[LoginFilter]
	<% } %>
declare @pFilters [gaporg].[<%= classify(name) %>Filters]
select * from [gaporg].[Get<%= classify(name) %>s](
<% if (model.isLoginFilter) { %>
@pLoginFilters
	<% } %>
	@pFilters,1,1000)
*/
create FUNCTION [gaporg].[Get<%= classify(name) %>s]
(
	<% if (model.isLoginFilter) { %>
		@pLoginFilters [gaporg].[LoginFilter] readonly,
	<% } %>
	@pFilters [gaporg].[<%= classify(name) %>Filters] readonly
	,@pageNumber int=1,
	@pageSize int=1
)
RETURNS @<%= camelize(name) %>s TABLE (
Id INT
<% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
,[<%= removeAccent(field.name) %>] <%= field.sqltype %>
<% } %>
<% for (let field of model.fields.filter(field=>field.isFk)) { %>
,[<%= removeAccent(field.name) %>] <%= field.sqltype %>
<% } %>

<% for (let fk of model.fk) { %>
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,[<%= fk2.columnName %>] <%= fk2.sqltype %>
	<% } %>
<% } %>

,SysInsertDateTime datetime
,[SysInsertUserId] int
,SysUpdateDateTime datetime
,[SysUpdateUserId] int
<% for (let fk of model.fk) { %>
	<% for (let field of fk.fields.filter(field=> field.isShow && !field.isKey)) { %>
	,[<%= fk.name %><%= removeAccent(field.name) %>] <%= field.sqltype %>
	<% } %>
	
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
		<% for (let field2 of fk2.fields.filter(field=> field.isShow && !field.isKey)) { %>
		,[<%= fk2.name %><%= removeAccent(field2.name) %>] <%= field2.sqltype %>
		<% } %>
	<% } %>
	
<% } %>
,[Count] int
)
AS
BEGIN 



IF(NOT EXISTS(SELECT 1 FROM @pFilters))
BEGIN
			INSERT INTO @<%= camelize(name) %>s
				SELECT v.[Id]
<% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
,v.[<%= removeAccent(field.name) %>]
<% } %>
<% for (let field of model.fields.filter(field=>field.isFk)) { %>
,v.[<%= removeAccent(field.name) %>]
<% } %>

<% for (let fk of model.fk) { %>
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,v.[<%= fk2.columnName %>]
	<% } %>
<% } %>

,v.[SysInsertDateTime]
,v.[SysInsertUserId]
,v.SysUpdateDateTime
,v.[SysUpdateUserId] 
<% for (let fk of model.fk) { %>
	<% for (let field of fk.fields.filter(field=> field.isShow && !field.isKey)) { %>
	,v.[<%= fk.name %><%= removeAccent(field.name) %>]
	<% } %>
	
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
		<% for (let field2 of fk2.fields.filter(field=> field.isShow && !field.isKey)) { %>
		,v.[<%= fk2.name %><%= removeAccent(field2.name) %>]
		<% } %>
	<% } %>
	
<% } %>
,count(*) OVER(PARTITION BY (select 1)) AS 'Count'
				from [gaporg].[V_<%= classify(name) %>] v 
	<% if (model.isLoginFilter) { %>
	
	join @pLoginFilters bf on			
		<% for (let field of model.fields.filter(field=>field.name == "RoleId" || field.name == "BlId")) { %>
			<% if (field.name == "RoleId") { %>
				(bf.[RoleId] is null or v.[RoleId] <=  bf.[RoleId] )  
			<% } %>
			<% if (field.name == "BlId") { %>
				(bf.[UserId] is null or v.BlId in (select [BlId] from [gaporg].[LinkUserBl] where [UserId]=bf.[UserId]))  
			<% } %>
		<% } %>
	<% } %>			
				ORDER BY v.[Id] DESC
	offset ((@pageNumber - 1) * @pageSize) rows
	fetch next @pageSize rows only
END
		ELSE
		BEGIN
		INSERT INTO @<%= camelize(name) %>s
			SELECT v.[Id]
<% for (let field of model.fields.filter(field=>!field.isKey && !field.isFk)) { %>
,v.[<%= removeAccent(field.name) %>]
<% } %>
<% for (let field of model.fields.filter(field=>field.isFk)) { %>
,v.[<%= removeAccent(field.name) %>]
<% } %>

<% for (let fk of model.fk) { %>
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
	,v.[<%= fk2.columnName %>]
	<% } %>
<% } %>
,v.[SysInsertDateTime]
,v.[SysInsertUserId]
,v.SysUpdateDateTime
,v.[SysUpdateUserId] 
<% for (let fk of model.fk) { %>
	<% for (let field of fk.fields.filter(field=> field.isShow && !field.isKey)) { %>
	,v.[<%= fk.name %><%= removeAccent(field.name) %>]
	<% } %>
	
	<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
		<% for (let field2 of fk2.fields.filter(field=> field.isShow && !field.isKey)) { %>
		,v.[<%= fk2.name %><%= removeAccent(field2.name) %>]
		<% } %>
	<% } %>
<% } %>
,count(*) OVER(PARTITION BY (select 1)) AS 'Count'
	from [gaporg].[V_<%= classify(name) %>] v 
	<% if (model.isLoginFilter) { %>
		join @pLoginFilters bf on
		<% for (let field of model.fields.filter(field=>field.name == "RoleId" || field.name == "BlId")) { %>
			<% if (field.name == "RoleId") { %>
				(bf.[RoleId] is null or v.[RoleId] <=  bf.[RoleId] )  
			<% } %>
			<% if (field.name == "BlId") { %>
				(bf.[UserId] is null or v.BlId in (select [BlId] from [gaporg].[LinkUserBl] where [UserId]=bf.[UserId]))  
			<% } %>
		<% } %>
	<% } %>
				join @pFilters f on
	
<% for (const [i,field] of model.filters.entries()) { %>
	<% if (field.name == "text") { %>
	(f.[<%= removeAccent(field.column1Name) %>] is null or v.[<%= removeAccent(field.column1Name) %>] like '%'+ f.[<%= removeAccent(field.column1Name) %>] +'%') <% if(i+1<model.filters.length){ %>AND <% } %>
	<% } else if(field.name == "selectMulti"){ %>
	(f.[<%= removeAccent(field.column1Name) %>] is null or v.[<%= removeAccent(field.column1Name) %>] in (select Data from [dbo].[ft_Split](f.[<%= removeAccent(field.column1Name) %>],','))) <% if(i+1<model.filters.length){ %>AND <% } %>
	<% } else if(field.name == "dateBetween"){ %>
	(f.[<%= removeAccent(field.column1Name) %>] is null or f.[<%= removeAccent(field.column1Name) %>] BETWEEN v.[<%= removeAccent(field.column1Name) %>] AND ISNULL(v.[<%= removeAccent(field.column2Name) %>],'2029-01-01')) <% if(i+1<model.filters.length){ %>AND <% } %>
	<% } else { %>
	(f.[<%= removeAccent(field.column1Name) %>] is null or f.[<%= removeAccent(field.column1Name) %>] = v.[<%= removeAccent(field.column1Name) %>]) <% if(i+1<model.filters.length){ %>AND <% } %>
	<% } %>
<% } %>
		ORDER BY v.[Id] DESC
	offset ((@pageNumber - 1) * @pageSize) rows
	fetch next @pageSize rows only

		END

		RETURN

		END

GO


