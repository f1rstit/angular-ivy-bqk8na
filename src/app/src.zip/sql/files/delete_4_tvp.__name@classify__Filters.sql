USE [Planet]
GO
DROP TYPE [gaporg].[<%= classify(name) %>Filters]
GO