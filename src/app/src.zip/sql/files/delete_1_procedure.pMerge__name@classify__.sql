USE [Planet]
GO
/****** Object:  StoredProcedure [gaporg].[pMerge_<%= classify(name) %>]    Script Date: 19/08/2021 19:04:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [gaporg].[pMerge_<%= classify(name) %>]
	-- Add the parameters for the stored procedure here
	@pVersionId int=1,
	@pUserLogId int=null,
	@pDebug bit=1

WITH RECOMPILE
AS
BEGIN
begin try

	DECLARE @vStartTime datetime = GETDATE()
	DECLARE @vRowCount INT=0
	DECLARE @vCommand NVARCHAR(MAX)

set @vCommand='EXEC [gaporg].[pMerge_<%= classify(name) %>] @pVersionId='+ cast(@pVersionId as varchar)+',@pDebug='+ cast(@pDebug as varchar)

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--------------------------------------
-- 1 - SOURCE FOR MERGE - NEW VERSION OF METADATA
--------------------------------------
SELECT 

<% for (let field of model.fields.filter(field=> !field.isKey)){ %>		
		public <%= field.ctype %><% if(field.ctype=="int"){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }			  
<%  } %>	
		
		
	@pVersionId as VersionId
      ,[Identifiant_BU] as Id
      ,/*[Entite_Organisationnelle] as*/ OrganisationalEntityId
      ,[Etat_Souverain] as SovereignStateCode
      ,/*[Entite_Juridique] as*/ LegalEntityId
      ,[Libelle_libre_BU] as ShortLabel
      ,[Libelle_long_BU_FR] as LabelFr
      ,[Libelle_long_BU_EN] as LabelEn
      ,[BU_parente] as ParentId
      ,[Niveau_hierarchique] as HierarchicalLevel
      ,[Type_de_centre] as CentreType
      ,[BU_corporate] as IsCorporate
      ,[Type_de_BU] as [Type]
	  ,convert(datetime, [Date_de_debut_de_validite], 103)   as ValidFromDate
      ,[BU_cedee_fermee] as Closed
      ,convert(datetime, [Date_legale_de_cession_fermeture], 103)as CloseDate
      ,[Statut_de_validite] as IsValid
      ,convert(datetime, [Date_de_derniere_modification], 103) as LastModifiedDate
      ,convert(datetime, [Date_de_publication], 103) as PublicationDate
      ,convert(datetime, [Date_de_desactivation], 103) as DeactivationDate
      ,convert(datetime, [Date_d_expiration], 103) as ExpirationDate
      ,[Declencheur_de_validation_si_le_pere_est_modifie] as TriggerValidationOnParentUpdated
      ,[SysInsertDateTime]
      ,[SysInsertUserId]
      ,[IsErrorNiveau_hierarchique]
      ,[Niveau_hierarchique_Message]
      ,[IsErrorType_de_BU]
      ,[Type_de_BU_Message]
      ,[IsError]
      ,[SovereignStateVersionId]
      ,[SovereignStateLabelFr]
      ,[SovereignStateLabelEn]
      ,[SovereignStateShortLabelFr]
      ,[SovereignStateShortLabelEn]
      ,[SovereignStateId]
	  
	  
INTO #Source
FROM [gaporg].[v_Import<%= classify(name) %>]
WHERE [SovereignStateVersionId]=@pVersionId
AND OrganisationalEntityId IS NOT NULL
AND LegalEntityId IS NOT NULL

IF(@pDebug=1) select * from #Source
--------------------------------------
-- 2 - TARGET FOR MERGE - SCOPE LES LIGNES ACTIVES
--------------------------------------
;WITH CTE_target AS (
           SELECT *
           FROM[gaporg].[<%= classify(name) %>]
)
--------------------------------------
-- 3 - MERGE
--------------------------------------
  MERGE INTO CTE_target AS target
  USING #Source AS source
      ON  target.VersionId = source.VersionId 
	  AND target.Id = source.Id 
	  WHEN MATCHED 
THEN UPDATE SET 
			target.[OrganisationalEntityId] = source.[OrganisationalEntityId]
			,target.[SovereignStateId] = source.[SovereignStateId]
			,target.[LegalEntityId] = source.[LegalEntityId]
			,target.[ShortLabel] = source.[ShortLabel]
			,target.[LabelFr] = source.[LabelFr]
			,target.[LabelEn] = source.[LabelEn]
			,target.[ParentId] = source.[ParentId]
			,target.[HierarchicalLevel] = source.[HierarchicalLevel]
			,target.[CentreType] = source.[CentreType]
			,target.[IsCorporate] = source.[IsCorporate]
			,target.[Type] = source.[Type]
			,target.[ValidFromDate] = source.[ValidFromDate]
			,target.[Closed] = source.[Closed]
			,target.[CloseDate] = source.[CloseDate]
			,target.[IsValid] = source.[IsValid]
			,target.[LastModifiedDate] = source.[LastModifiedDate]
			,target.[PublicationDate] = source.[PublicationDate]
			,target.[DeactivationDate] = source.[DeactivationDate]
			,target.[ExpirationDate] = source.[ExpirationDate]
			,target.[TriggerValidationOnParentUpdated] = source.[TriggerValidationOnParentUpdated]
  WHEN NOT MATCHED BY TARGET
    THEN INSERT
           ([Id],
			[VersionId],
			[OrganisationalEntityId],
			[SovereignStateId],
			[LegalEntityId],
			[ShortLabel],
			[LabelFr],
			[LabelEn],
			[ParentId],
			[HierarchicalLevel],
			[CentreType],
			[IsCorporate],
			[Type],
			[ValidFromDate],
			[Closed],
			[CloseDate],
			[IsValid],
			[LastModifiedDate],
			[PublicationDate],
			[DeactivationDate],
			[ExpirationDate],
			[TriggerValidationOnParentUpdated])
    VALUES
    ( source.[Id],
			source.[VersionId],
			source.[OrganisationalEntityId],
			source.[SovereignStateId],
			source.[LegalEntityId],
			source.[ShortLabel],
			source.[LabelFr],
			source.[LabelEn],
			source.[ParentId],
			source.[HierarchicalLevel],
			source.[CentreType],
			source.[IsCorporate],
			source.[Type],
			source.[ValidFromDate],
			source.[Closed],
			source.[CloseDate],
			source.[IsValid],
			source.[LastModifiedDate],
			source.[PublicationDate],
			source.[DeactivationDate],
			source.[ExpirationDate],
			source.[TriggerValidationOnParentUpdated])
             WHEN NOT MATCHED BY SOURCE AND target.VersionId = @pVersionId
    THEN DELETE output $action AS ActionType,inserted.*,deleted.*;

			 	 end try
	begin catch
	DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

		SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

			exec utility.pA_LogProc
			 @pObjectID       = @@PROCID,
			 @pUserLogId	  = @pUserLogId,
			 @pRowCount		  = @vRowCount,
			 @pCommand		  = @vCommand,
			 @pStartTime      = @vStartTime,
			 @ErrorMessage = @ErrorMessage,
            @ErrorSeverity = @ErrorSeverity,
            @ErrorState = @ErrorState;

RAISERROR (@ErrorMessage, -- Message text.
                   @ErrorSeverity, -- Severity.
                   @ErrorState -- State.
                   );
		RETURN
end catch

	IF(@pDebug=1)	
exec utility.pA_LogProc
 @pObjectID       = @@PROCID,
 @pUserLogId	  = @pUserLogId,
 @pRowCount		  = @vRowCount,
 @pCommand		  = @vCommand,
 @pStartTime      = @vStartTime;

END
