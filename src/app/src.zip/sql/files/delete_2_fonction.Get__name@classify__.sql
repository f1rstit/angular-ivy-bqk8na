USE [Planet]
GO
DROP FUNCTION [gaporg].[Get<%= classify(name) %>s]
GO