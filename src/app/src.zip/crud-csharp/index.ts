import {
  apply,
  chain,
  MergeStrategy,
  mergeWith,
  move,
  Rule,
  SchematicContext,
  SchematicsException,
  template,
  Tree,
  url
} from '@angular-devkit/schematics';
import { join, normalize } from 'path';
import { getWorkspace } from '@schematics/angular/utility/workspace';
import { strings as stringUtils } from '@angular-devkit/core';
import * as JSON5 from 'json5';
import * as crudModelUtils from '../utils/crud-model-utils'

export async function setupOptions(host: Tree, options: any): Promise<Tree> {
  const workspace = await getWorkspace(host);
  if (!options.project) {
    options.project = workspace.projects.keys().next().value;
  }
  const project = workspace.projects.get(options.project);
  if (!project) {
    throw new SchematicsException(`Invalid project name: ${options.project}`);
  }

  options.path = join(normalize(project.root), 'src/app/generate');
  return host;
}

export function crudCsharp(_options: any): Rule {
  return async (tree: Tree, _context: SchematicContext) => {
    await setupOptions(tree, _options);

    console.warn("_options",_options);
    const modelFile = `${_options.path}/${_options.model}`;
    console.info("modelFile",modelFile);
    const modelBuffer = tree.read(modelFile);
    console.info("modelBuffer",modelBuffer);
    const modelJson = modelBuffer?.toString('utf-8');
    let model;
    if(typeof modelJson !== 'undefined'){
      model = JSON5.parse(modelJson);
    }
    
    console.info("model",model);
    const movePath = normalize(_options.path);
    const templateSource = apply(url('./files'), [
      template({
        ...stringUtils,
        ..._options, 
        ...crudModelUtils as any,
        model}),
      move(movePath)
    ]);

    return chain([mergeWith(templateSource, MergeStrategy.Overwrite)]);
  };
}