﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Opr.<%= classify(project) %>.Business.Contracts;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.Planet.Domain.Helpers;
using Opr.<%= classify(project) %>.Domain.ViewModels;
using System.Collections.Generic;

namespace Opr.<%= classify(project) %>.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class <%= classify(name) %>Controller : ControllerBase
    {
        private readonly I<%= classify(name) %>Service _<%= camelize(name) %>Service;
		<% if(!model.isRef){ %>
		private readonly IMapper _mapper;
		private readonly IContextService _context;
		<% } %>

        public <%= classify(name) %>Controller(I<%= classify(name) %>Service <%= camelize(name) %>Service<% if(!model.isRef){ %>, IMapper mapper, IContextService context<% } %>)
        {
            _<%= camelize(name) %>Service = <%= camelize(name) %>Service;
			<% if(!model.isRef){ %>
			_mapper = mapper;
			_context = context;
			<% } %>
        }

		<% if(!model.isRef){ %>
		[HttpPost]
        [Route("list")]
        public IEnumerable<<%= classify(name) %>VM> GetAll([FromBody] <%= classify(name) %>FiltersVM filters){
			LoginFilter loginFilters = _context.User.getLoginFilter();
			<% if(model.fields.filter(field => field.property  == "Version").length > 0){ %>filters.VersionId = _context.VersionId;<% } %>
            return _mapper.Map<IEnumerable<<%= classify(name) %>VM>>(_<%= camelize(name) %>Service.GetAll(loginFilters, filters));
		}  

        [HttpGet]
        [Route("{id:int}")]
        public <%= classify(name) %>VM Get(int id) => _mapper.Map<<%= classify(name) %>VM>(_<%= camelize(name) %>Service.Get(id));

        [HttpDelete]
        [Route("{ids}")]
        public bool Delete(string ids) => this._<%= camelize(name) %>Service.Delete(ids);

        [HttpPost]
        [Route("create")]
        public <%= classify(name) %>VM Create([FromBody] <%= classify(name) %>CreateVM <%= camelize(name) %>) => this._<%= camelize(name) %>Service.Create(<%= camelize(name) %>);

        [HttpPost]
        [Route("update")]
        public bool Update([FromBody] <%= classify(name) %>UpdateVM <%= camelize(name) %>) => this._<%= camelize(name) %>Service.Update(<%= camelize(name) %>);
		<% } else { %>
		[HttpGet]
        public IEnumerable<<%= classify(name) %>> GetAll() => _<%= camelize(name) %>Service.GetAll();
		<% } %>
		
		<% if(model.isImport){ %>
		[HttpPost]
        [Route("validate")]
        public bool ValidateImport() => this._<%= camelize(name) %>Service.ValidateImport(_context.VersionId);
		<% } %>
		
		[HttpGet]
        [Route("getColumnDisplay")]
        public IEnumerable<string> GetColumnDisplay() => _<%= camelize(name) %>Service.GetColumnDisplay(_context.User.RoleId);
    }
}
