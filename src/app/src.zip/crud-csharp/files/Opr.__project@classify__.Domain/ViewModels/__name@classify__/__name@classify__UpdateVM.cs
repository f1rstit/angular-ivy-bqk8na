﻿using System;

namespace Opr.<%= classify(project) %>.Domain.ViewModels
{
    public class <%= classify(name) %>UpdateVM : <%= classify(name) %>CreateVM
    {
		public int Id { get; set; }		
    }
}
