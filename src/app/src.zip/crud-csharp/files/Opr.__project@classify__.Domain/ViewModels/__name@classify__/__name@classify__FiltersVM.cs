﻿using System;

namespace Opr.<%= classify(project) %>.Domain.ViewModels
{
    public class <%= classify(name) %>FiltersVM : PageFilterVM
    {
		<% for (let field of model.filters) { %>		
		public <%= field.ctype %>? <%= removeAccent(field.column1Name) %> { get; set; }			  
		<%  } %>	
    }
}
