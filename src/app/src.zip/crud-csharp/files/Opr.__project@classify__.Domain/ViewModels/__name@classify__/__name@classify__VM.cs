﻿using System;

namespace Opr.<%= classify(project) %>.Domain.ViewModels
{
    public class <%= classify(name) %>VM
    {
		<% for (let field of model.fields) { %>		
		public <%= field.ctype %><% if(field.isNullable){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }			  
		<%  } %>	
		
		<% for (let fk of model.fk) { %>
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
			public <%= fk2.ctype %> <%= removeAccent(fk2.columnName) %> { get; set; }		
			<% } %>
		<% } %>

		<% for (let fk of model.fk) { %>
			<% for (let field of fk.fields.filter(field=> field.isShow && !field.isKey)) { %>
			public <%= field.ctype %>	<%= fk.name %><%= removeAccent(field.name) %> { get; set; }		
			<% } %>
			
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
				<% for (let field2 of fk2.fields.filter(field=> field.isShow && !field.isKey)) { %>
				public <%= field2.ctype %>	<%= fk2.name %><%= removeAccent(field2.name) %> { get; set; }		
				<% } %>
			<% } %>
	
		<% } %>

		public int Count { get; set; }		
    }
}
