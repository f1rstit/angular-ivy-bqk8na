﻿using System;

namespace Opr.<%= classify(project) %>.Domain.ViewModels
{
    public class <%= classify(name) %>CreateVM
    {
		<% for (let field of model.fields.filter(field => !field.isKey)) { %>		
		public <%= field.ctype %><% if(field.isNullable){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }			  
		<%  } %>	
		
    }
}
