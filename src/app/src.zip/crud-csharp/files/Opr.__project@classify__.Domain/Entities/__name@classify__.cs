﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Opr.<%= classify(project) %>.Domain.Entities
{

    [Table("<%= model.tableName %>", Schema ="<%= model.schema %>")]
	public class <%= classify(name) %> <% if(!model.isRef){ %> : AuditableEntity<% } %>
    {	
		<% for (const field of getFilterFields(model)) { %>
		
		[<% if(field.isKey){ %>Key,<% } %>Column(<% if(typeof(field.keyOrder) !== "undefined"){ %>Order = <%= field.keyOrder %>,<% } %>TypeName = "<%= field.sqltype %>")]
        public <%= field.ctype %><% if(field.isNullable){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }
					  
		<%  } %>	  
		
		<% for (let fk of model.fk) { %>		
			[ForeignKey(nameof(<%= classify(fk.columnName) %>))]
			public virtual <%= classify(fk.type) %> <%= classify(fk.name) %> { get; set; }					  
		<%  } %>	
    }
}
