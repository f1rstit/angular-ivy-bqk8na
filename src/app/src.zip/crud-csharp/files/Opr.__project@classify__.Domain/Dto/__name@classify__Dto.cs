using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Opr.<%= classify(project) %>.Domain.Entities
{

	public class <%= classify(name) %>Dto <% if(!model.isRef){ %> : AuditableEntity<% } %>
    {	
		<% for (const field of model.fields) { %>
		
		[<% if(field.isKey){ %>Key,<% } %>Column(<% if(typeof(field.keyOrder) !== "undefined"){ %>Order = <%= field.keyOrder %>,<% } %>TypeName = "<%= field.sqltype %>")]
        public <%= field.ctype %><% if(field.isNullable){ %>?<% } %> <%= removeAccent(field.name) %> { get; set; }
					  
		<%  } %>	  
		
		<% for (let fk of model.fk) { %>
			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
			[Column(TypeName = "<%= fk2.sqltype %>")]
			public <%= fk2.ctype %>? <%= removeAccent(fk2.columnName) %> { get; set; }
			<% } %>
		<% } %>
				
		public int? Count { get; set; }
		
		<% for (let fk of model.fk) { %>		
			[ForeignKey(nameof(<%= classify(fk.columnName) %>))]
			public virtual <%= classify(fk.type) %> <%= classify(fk.name) %> { get; set; }	

			<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>
			
			[ForeignKey(nameof(<%= classify(fk2.columnName) %>))]
			public virtual <%= classify(fk2.type) %> <%= classify(fk2.name) %> { get; set; }	
			<% } %>
			
		<%  } %>	
    }
}
