﻿using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.Domain.ViewModels;
using System.Collections.Generic;

namespace Opr.<%= classify(project) %>.Business.Contracts
{
    public interface I<%= classify(name) %>Service
    {
        public IEnumerable<<%= classify(name) %><% if(!model.isRef){ %>VM<% } %>> GetAll(<% if(!model.isRef){ %>LoginFilter loginFilters,<%= classify(name) %>FiltersVM filters<% } %>);
		<% if(!model.isRef){ %>
			<%= classify(name) %>VM Get(int id);
			bool Delete(string ids);
			bool Update(<%= classify(name) %>UpdateVM <%= camelize(name) %>);
			<%= classify(name) %>VM Create(<%= classify(name) %>CreateVM <%= camelize(name) %>);
		<% } %>
		IEnumerable<string> GetColumnDisplay(int roleId);
		
		<% if(model.isImport){ %>
		bool ValidateImport(int versionId);
		<% } %>
    }
}
