﻿using AutoMapper;
using Opr.Planet.Data.Core;
using Opr.<%= classify(project) %>.Business.Contracts;
using Opr.<%= classify(project) %>.Business.Core;
using Opr.<%= classify(project) %>.Data.Contracts;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.Domain.ViewModels;
using System;
using System.Collections.Generic;

namespace Opr.<%= classify(project) %>.Business.Services
{
    public class <%= classify(name) %>Service : <% if(!model.isRef){ %>Service,<% } %> I<%= classify(name) %>Service
    {
        private <%= model.repository %> _<%= camelize(name) %>Repository { get; set; }
		private IContextService _context { get; set; }
		private readonly IMapper _mapper;

        public <%= classify(name) %>Service(<%= model.repository %> <%= camelize(name) %>Repository, IContextService context, IMapper mapper)
        {
            _<%= camelize(name) %>Repository = <%= camelize(name) %>Repository;
			_context = context;
			_mapper = mapper;
        }

        public IEnumerable<<%= classify(name) %><% if(!model.isRef){ %>VM<% } %>> GetAll(<% if(!model.isRef){ %>LoginFilter loginFilters,<%= classify(name) %>FiltersVM filters<% } %>)
        {
            return _<%= camelize(name) %>Repository.<% if(!model.isRef){ %>GetAll(loginFilters, filters)<% } else { %>All()<% } %>;
        }
		
		<% if(!model.isRef){ %>
			public <%= classify(name) %>VM Get(int id)
			{
				return _<%= camelize(name) %>Repository.Get(id);
			}

			public <%= classify(name) %>VM Create(<%= classify(name) %>CreateVM <%= camelize(name) %>)
			{
				<%= classify(name) %> _<%= camelize(name) %> = _mapper.Map<<%= classify(name) %>>(<%= camelize(name) %>);
				<% if(model.fields.filter(field => field.property  == "Version").length > 0){ %>_<%= camelize(name) %>.VersionId = _context.VersionId;<% } %>
				_<%= camelize(name) %>.SysInsertUserId = _context.User.Id;
				_<%= camelize(name) %>Repository.Add(_<%= camelize(name) %>);
				return _mapper.Map<<%= classify(name) %>VM>(_<%= camelize(name) %>);   
			}
			public bool Update(<%= classify(name) %>UpdateVM <%= camelize(name) %>)
			{
				<%= classify(name) %> _<%= camelize(name) %> = _mapper.Map<<%= classify(name) %>>(<%= camelize(name) %>);
				_<%= camelize(name) %>.SysUpdateDateTime = DateTime.Now;
				_<%= camelize(name) %>.SysUpdateUserId = _context.User.Id;
				_<%= camelize(name) %>Repository.Update(_<%= camelize(name) %>);
				return true;
			}
			public bool Delete(string ids)
			{
				string[] deleteIds = ids.Split(',');
				foreach (var id in deleteIds)
				{
					_<%= camelize(name) %>Repository.RemoveById(Int32.Parse(id));
				}         
				return true;
			}
		<% } %>
		
		public IEnumerable<string> GetColumnDisplay(int roleId)
		{
			return _<%= camelize(name) %>Repository.GetColumnDisplay(roleId,"<%= classify(name) %>");
		}
		
		<% if(model.isImport){ %>
		public bool ValidateImport(int versionId)
		{
			return _<%= camelize(name) %>Repository.ValidateImport(versionId);
		}
		<% } %>
    }

}
