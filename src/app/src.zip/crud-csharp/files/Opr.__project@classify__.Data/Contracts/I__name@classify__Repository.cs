﻿using Opr.<%= classify(project) %>.Data.Core;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.Domain.ViewModels;
using System.Collections.Generic;

namespace Opr.<%= classify(project) %>.Data.Contracts
{
    public interface I<%= classify(name) %>Repository : IRepository<<%= classify(name) %>>
    {
		IEnumerable<<%= classify(name) %>VM> GetAll(LoginFilter loginFilters, <%= classify(name) %>FiltersVM filters);
		
		<%= classify(name) %>VM Get(int id);
		
		<% if(model.isImport){ %>
		bool ValidateImport(int versionId);
		<% } %>
    }
}
