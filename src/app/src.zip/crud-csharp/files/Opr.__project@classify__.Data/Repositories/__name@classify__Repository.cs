﻿using Microsoft.Data.SqlClient;
using Opr.<%= classify(project) %>.Data.Contracts;
using Opr.<%= classify(project) %>.Data.Core;
using Opr.<%= classify(project) %>.Data.Helpers;
using Opr.<%= classify(project) %>.Domain.Entities;
using Opr.<%= classify(project) %>.Domain.ViewModels;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;
using AutoMapper;

namespace Opr.<%= classify(project) %>.Data.Repositories
{
    public class <%= classify(name) %>Repository : RepositoryEntity<Domain.Entities.<%= classify(name) %>>, I<%= classify(name) %>Repository
    {
		private readonly IMapper _mapper;
		
        public <%= classify(name) %>Repository(IUnitOfWork uow, IMapper mapper) : base(uow){
				_mapper = mapper;
		}
		
		public IEnumerable<<%= classify(name) %>VM> GetAll(LoginFilter loginFilters, <%= classify(name) %>FiltersVM filters)
        {
			int page = 1;
			int pagesize = 100000;
			if (filters.Page != null) page = (int)filters.Page;
			if (filters.PageSize != null) pagesize = (int)filters.PageSize;
			
            var parameters = new SqlParameter[]
            {
				<% if (model.isLoginFilter) { %>
					ToSqlParameter("@loginFilters", loginFilters),
				<% } %>			
                ToSqlParameter("@filters", filters),
                ToSqlParameter("@pageNumber", page),
                ToSqlParameter("@pageSize", pagesize)
            };

            var result = Context.<%= classify(name) %>Dtos
                .FromSqlRaw(@"select 
				<% for (let field of model.fields) { %>		
				<%= removeAccent(field.name) %>,		  
				<%  } %>	
				<% for (let fk of model.fk) { %>
					<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
					<%= fk2.columnName %>,
					<% } %>
				<% } %>
				[SysInsertDateTime],[SysUpdateDateTime],[SysInsertUserId],[SysUpdateUserId],[Count]
				from [gaporg].[Get<%= classify(name) %>s](
				<% if (model.isLoginFilter) { %>
					@loginFilters, 
				<% } %>		
				@filters, @pageNumber, @pageSize)", parameters)
				<% for (let fk of model.fk) { %>
                .Include(s => s.<%= classify(fk.name) %>)
				<% } %>
				<% for (let fk of model.fk) { %>
					<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
					.Include(s => s.<%= classify(fk2.name) %>)
					<% } %>
				<% } %>
                .ToList();

            return _mapper.Map<IEnumerable<<%= classify(name) %>VM>>(result);
        }

		public <%= classify(name) %>VM Get(int id)
        {
			var result = Context.<%= classify(name) %>s
			<% for (let fk of model.fk) { %>
                .Include(s => s.<%= classify(fk.name) %>)
				<% } %>
				
				<% for (let fk of model.fk) { %>
				.Include(s => s.<%= classify(fk.name) %>)
					<% for (let fk2 of fk.fk2.filter(fk2=> fk2.tableName != "RefVersion" && fk2.tableName != "RefStatut")) { %>	
					.ThenInclude(it => it.<%= classify(fk2.name) %>)
					<% } %>
				<% } %>

				.SingleOrDefault(x => x.Id == id);

			return _mapper.Map<<%= classify(name) %>VM>(result);
		}
		
        public static SqlParameter ToSqlParameter(string name, int i) =>
            new SqlParameter { ParameterName = name, SqlDbType = SqlDbType.Int, Value = i };

        public static SqlParameter ToSqlParameter(string name, <%= classify(name) %>FiltersVM filters)
        {
            var table = new DataTable();
			<% for (let field of model.filters) { %>
				table.Columns.Add("<%= removeAccent(field.column1Name) %>", typeof(<%= field.ctype %>));
			<% } %>


			var row = table.NewRow();
			<% for (let field of model.filters) { %>
				row["<%= removeAccent(field.column1Name) %>"] = DbValueHelper.GetDbValueFromNullable(filters.<%= removeAccent(field.column1Name) %><% if(field.type=="int"){ %>.ConvertMinus1toNull()<% } %>);
			<% } %>
			table.Rows.Add(row);
            

            return new SqlParameter(name, SqlDbType.Structured)
            {
                TypeName = "gaporg.<%= classify(name) %>Filters",
                Value = table
            };
        }
		
		<% if(model.isImport){ %>
		public bool ValidateImport(int versionId)
        {
            CallProcedure("gaporg.pMerge_<%= classify(name) %>", new SqlParameter[]
                {
                    new SqlParameter("@pVersionId", versionId)
                });
            return true;
        }
		<% } %>
    }
}
